package net.vukrosic.custommobswordsmod.util.custom;

import net.minecraft.util.math.BlockPos;

public interface CompassAnglePredicateProviderExt {
    void setOverworldPreyPos(BlockPos pos);
}
