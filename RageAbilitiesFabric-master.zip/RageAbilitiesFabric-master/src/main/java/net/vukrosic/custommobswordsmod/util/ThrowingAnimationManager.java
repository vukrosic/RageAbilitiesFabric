package net.vukrosic.custommobswordsmod.util;

import net.minecraft.entity.player.PlayerEntity;

public class ThrowingAnimationManager {
    public static PlayerEntity throwingPlayer;
}
