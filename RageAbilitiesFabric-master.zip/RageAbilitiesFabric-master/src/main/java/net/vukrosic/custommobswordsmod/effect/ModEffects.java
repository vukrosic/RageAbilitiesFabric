package net.vukrosic.custommobswordsmod.effect;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.vukrosic.custommobswordsmod.CustomMobSwordsMod;

public class ModEffects {


/*
    private static StatusEffect registerCarbonPoisoningEffect(String name) {
        return Registry.register(Registry.STATUS_EFFECT, new Identifier(CustomMobSwordsMod.MOD_ID, name),
                new CarbonPoisoningEffect(StatusEffectCategory.HARMFUL, 3124687));
    }
*/
    public static void registerEffects() {
        //CARBONPOISONING = registerCarbonPoisoningEffect("carbonpoisoning");
    }


}
