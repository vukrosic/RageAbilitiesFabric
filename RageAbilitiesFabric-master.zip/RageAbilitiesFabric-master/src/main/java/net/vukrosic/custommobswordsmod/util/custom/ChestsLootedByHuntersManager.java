package net.vukrosic.custommobswordsmod.util.custom;

import blue.endless.jankson.JsonArray;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;

public class ChestsLootedByHuntersManager {
    public static int numberOfChestsLootedByHunters = 0;
    // make a list of chest positions
    public static ArrayList<BlockPos> lootedChests = new ArrayList<BlockPos>();
}
