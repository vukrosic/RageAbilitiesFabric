package net.vukrosic.custommobswordsmod.entity.custom;

public interface LivingEntityExt {
    boolean getBeingThrownByPrey();
    void setBeingThrownByPrey(boolean beingThrownByPrey);
    void setBeingPickedByPlayer(boolean beingPickedByPlayer);

}
