package net.vukrosic.custommobswordsmod.util.abilities;

public class Bingo {
}
