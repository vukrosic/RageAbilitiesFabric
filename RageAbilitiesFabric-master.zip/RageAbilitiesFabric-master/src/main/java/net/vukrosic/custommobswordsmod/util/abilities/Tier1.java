package net.vukrosic.custommobswordsmod.util.abilities;

public class Tier1 {
    public static void pickUpMob() {

    }
}
