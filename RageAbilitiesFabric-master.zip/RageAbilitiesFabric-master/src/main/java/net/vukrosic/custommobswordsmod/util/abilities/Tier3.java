package net.vukrosic.custommobswordsmod.util.abilities;

public class Tier3 {
}
