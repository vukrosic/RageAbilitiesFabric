package net.vukrosic.custommobswordsmod.util.custom;

public interface HandledScreenExt {
    void setBurn(boolean burn);
}
